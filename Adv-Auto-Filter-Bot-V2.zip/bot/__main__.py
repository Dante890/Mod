#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# (c) @The_dante444

from .bot import Bot

app = Bot()
app.run()